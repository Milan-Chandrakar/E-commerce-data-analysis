/* MID COURSE PROJECT for year 2012
1.MONTHY TRENDS FOR GSEARCH (sessions AND ORDERS)
2.MONTHY TRENDS FOR GSEARCH split in brand and non brand campaigns
3.MONTHLY TRENDS FOR GSEARCH NON BRANDED AND ORDERS SPLIT BY DEVICE TYPE
4.MONTHLY TRENDS FOR GSEARCH AND OTHER SOURCES
5. MONTHLY TRENDS FOR sessions to order conversion rates

*/

-- 1st 

SELECT month(w.created_at) as month,
count(distinct w.website_session_id) as gsearch_sessions,
count(o.order_id) as orders
from website_sessions w
left join orders o
on w.website_session_id = o.website_session_id
where w.created_at <= '2012-11-27' and utm_source = 'gsearch'
group by month(w.created_at);

-- 2nd
SELECT month(w.created_at) as month,
count(DISTINCT case when utm_campaign = 'nonbrand' then website_session_id else null end) as gsearch_non_branded,
count(distinct case when utm_campaign = 'brand' then website_session_id else null end) as gsearch_branded
from website_sessions w
where w.created_at <= '2012-11-27' and utm_source = 'gsearch'
group by month(w.created_at);

-- 3rd
SELECT month(w.created_at) as month,
count(case when device_type = 'mobile' then w.website_session_id else null end) as mobile_sessions,
count(case when device_type = 'desktop' then w.website_session_id else null end) as desktop_sessions,
count(case when device_type = 'mobile' then o.order_id else null end) as mobile_orders,
count(case when device_type = 'desktop' then o.order_id else null end) as desktop_orders
from website_sessions w
left join orders o on
w.website_session_id = o.website_session_id
where w.created_at <= '2012-11-27' and utm_source = 'gsearch' and utm_campaign = 'nonbrand'
group by month(w.created_at);

-- 4th
SELECT min(date(w.created_at)) as start_date,
count(DISTINCT case when utm_source ='gsearch' then website_session_id else null end) as gsearch_sessions,
count(distinct case when utm_source = 'bsearch' then website_session_id else null end) as bsearch_sessions,
count(DISTINCT case when utm_source is null then website_session_id end) as other_sessions
from website_sessions w
where w.created_at <= '2012-11-27' 
group by month(w.created_at);

-- 5th
select month(w.created_at) as month,
COUNT(distinct w.website_session_id) as sessions,
COUNT(distinct o.order_id) as orders,
COUNT(distinct o.order_id)/COUNT(distinct w.website_session_id) as conversion_rate
from website_sessions w
left join orders o
on w.website_session_id = o.website_session_id
where w.created_at <= '2012-11-27' 
group by month(w.created_at);

-- 6th
-- find when test started
SELECT min(website_pageview_id) as 1st_lander
from website_pageviews
where pageview_url = '/lander-1'; -- returns 23504 

-- find landing pages in the test peroid
CREATE TEMPORARY TABLE landing_pages
select s.website_session_id, min(p.website_pageview_id) as landing_pages
from website_pageviews p
inner join website_sessions s
on p.website_session_id = s.website_session_id
and s.created_at <'2012-07-28' and p.website_pageview_id >= '23504'
and utm_source = 'gsearch' and utm_campaign = 'nonbrand'
GROUP BY s.website_session_id;

-- finding landing pages sessions
CREATE TEMPORARY TABLE home_lander_sessions
select w.website_session_id, w.pageview_url as landing_pages
from landing_pages l
left join website_pageviews w
on w.website_pageview_id = l.landing_pages
WHERE w.pageview_url in ('/home','/lander-1');

-- joining orders with pages
CREATE TEMPORARY TABLE pages_with_orders
select h.website_session_id,h.landing_pages,o.order_id
from home_lander_sessions h
left join orders o on
h.website_session_id = o.website_session_id;

-- finding sessions to order conversion rates
select landing_pages, count(DISTINCT order_id), count(DISTINCT website_session_id),
count(DISTINCT order_id)/ count(DISTINCT website_session_id) as conv_rate
from pages_with_orders
group by 1;
-- returns values 0.0318 (home) and 0.0406 (lander) implies 0.0406-0.0318 = 0.0088 is additional conversion_rate,i.e.,
-- lander gives this much more orders compared to home

-- now find out last home session after which all all sessions are lander so that we can calculate additional orders 
-- that lander has provided

select Max(s.website_session_id) as most_recent_home_page_session_id -- where lander test started
from website_sessions s
left join website_pageviews p
on s.website_session_id = p.website_session_id
where s.created_at <= '2012-11-27' and utm_source = 'gsearch' and utm_campaign = 'nonbrand' and pageview_url = '/home';
-- returns id 17145

select count(website_session_id) as sessions_since_test_started
from website_sessions
where created_at <= '2012-11-27' and utm_source = 'gsearch' and utm_campaign = 'nonbrand' and website_session_id> 17145;
-- returns 22972 =>
-- 0.0087 x 22972 = 202 orders since 1st lander session,i.e. additional 202 orders gained by lander test
