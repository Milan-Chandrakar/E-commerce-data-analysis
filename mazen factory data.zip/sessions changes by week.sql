SELECT week(created_at),min(date(created_at)) as week_start_date, COUNT(DISTINCT website_session_id)
FROM website_sessions
WHERE created_at BETWEEN '2012-04-15' and '2012-05-10' and utm_campaign = 'nonbrand' and 
utm_source= 'gsearch'
GROUP BY week(created_at)
