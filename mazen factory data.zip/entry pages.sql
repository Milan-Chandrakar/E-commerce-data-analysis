CREATE TEMPORARY TABLE first_pageview
SELECT website_session_id, min(website_pageview_id) as min_pageview
FROM website_pageviews
WHERE website_pageview_id <1000
GROUP BY website_session_id;

Select w.pageview_url as landing_pages, count(DISTINCT f.website_session_id) as sessions
FROM first_pageview f
left join 
website_pageviews w on w.website_pageview_id = f.min_pageview
GROUP BY landing_pages

