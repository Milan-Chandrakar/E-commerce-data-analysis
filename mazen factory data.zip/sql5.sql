SELECT primary_product_id, order_id,items_purchased
FROM orders
WHERE order_id BETWEEN 21000 AND
-- GROUP BY 1