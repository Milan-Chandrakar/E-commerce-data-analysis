SELECT primary_product_id, 
count(DISTINCT CASE WHEN items_purchased =1 THEN order_id End) as count_one_items_purchased,
count(DISTINCT CASE WHEN items_purchased =2 THEN order_id End) as count_two_items_purchased
FROM orders
WHERE order_id BETWEEN 31000 AND 32000
GROUP BY 1